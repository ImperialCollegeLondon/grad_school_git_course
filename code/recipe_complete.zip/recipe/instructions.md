* chop avocados
* chop onion
* squeeze lime
* add salt
* and mix well
