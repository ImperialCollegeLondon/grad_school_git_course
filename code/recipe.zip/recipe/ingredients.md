* 2 avacados
* 1 lime
* 2 tsp salt
